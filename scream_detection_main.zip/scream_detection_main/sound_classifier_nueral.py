# dataset for this model can be easily prepare by datasetmaker.py file
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from sklearn.metrics import classification_report
from keras.optimizers import Adam

# Load dataset (label di kolom ke-0, jadi tidak perlu index_col=0)
df = pd.read_csv('newresources.csv', engine='c')

# Baca batas antara data latih dan data uji
with open("begining index of testing files.txt", "r") as file:
    row_num_for_verification_of_model = int(file.read())

# Label dan fitur
column_number_of_csv_having_labels = 1  # label = kolom pertama
X = df.iloc[:row_num_for_verification_of_model, 2:]  # fitur training
y = df.iloc[:row_num_for_verification_of_model, column_number_of_csv_having_labels]  # label training

X2 = df.iloc[row_num_for_verification_of_model:, 2:]  # fitur testing
actual_y = df.iloc[row_num_for_verification_of_model:, column_number_of_csv_having_labels]  # label testing

# Hitung jumlah fitur otomatis (tanpa file)
total_features = X.shape[1]

# Simpan jumlah fitur (opsional, jika masih ingin pakai file untuk referensi eksternal)
with open("input dimension for model.txt", "w") as f:
    f.write(str(total_features))

# Build model
model = Sequential()
model.add(Dense(64, input_dim=total_features, activation='relu'))
model.add(Dense(32, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

model.compile(
    optimizer=Adam(learning_rate=0.0005),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Train
history = model.fit(X, y, validation_split=0.33, epochs=150, batch_size=50)

# Evaluate
_, accuracy = model.evaluate(X, y)
print('Accuracy: %.2f' % (accuracy * 100))

# Predict
predictions = model.predict(X2)
rounded = [round(x[0]) for x in predictions]

print("Predicted value is:", rounded)
print("Actual value was:", list(actual_y))

print(classification_report(actual_y, rounded))


# Save model
model.save('model_scream.keras')

