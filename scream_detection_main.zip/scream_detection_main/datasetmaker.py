# this file is made for sound_classifier_nueral.py
# positive sound mean the sound that we want to predict
# negative sound mean sound except positive sound
import time
import psutil
import numpy as np
import pandas as pd
import os,threading
from sklearn.preprocessing import StandardScaler
from scipy.io.wavfile import read
import os
from imblearn.over_sampling import SMOTE

class scream():
    def adder(self):
        files = os.listdir('negative')
        arr = []
        max_len = 0

        # NEGATIVE
        for i in files:
            num = int(0)
            i = 'negative/' + i
            try:
                _, rs = read(i)
                rs = rs.astype(np.int16)
                max_len = max(max_len, len(rs))
                rs = np.insert(rs, 0, num)
                arr.append(pd.Series(rs))
                self.ctr += 1
            except Exception as e:
                print(f"removed {i}, error: {e}")
                os.remove(i)
                continue

        # POSITIVE
        files = os.listdir('positive')
        for i in files:
            num = int(1)
            i = 'positive/' + i
            try:
                _, rs = read(i)
                rs = rs.astype(np.int16)
                max_len = max(max_len, len(rs))
                rs = np.insert(rs, 0, num)
                arr.append(pd.Series(rs))
                self.ctr += 1
            except Exception as e:
                print(f"removed {i}, error: {e}")
                os.remove(i)
                continue

        self.starting_index_not_to_be_shuffled = self.ctr
        with open("begining index of testing files.txt", "w") as file:
            file.write(str(self.ctr))
        print(f"{self.ctr} training files have been added.")

        time.sleep(1)

        # TESTING
        files = os.listdir('testing')
        for i in files:
            num = int(1) if i.startswith("1") else int(0)
            i = 'testing/' + i
            try:
                _, rs = read(i)
                rs = rs.astype(np.int16)
                max_len = max(max_len, len(rs))
                rs = np.insert(rs, 0, num)
                arr.append(pd.Series(rs))
                self.ctr += 1
            except Exception as e:
                print(f"removed {i}, error: {e}")
                os.remove(i)
                continue

        # Padding
        arr_padded = [s.reindex(range(max_len + 1), fill_value=0) for s in arr]
        df = pd.DataFrame(arr_padded).dropna(axis=1)
        df.to_csv('resources.csv', index=False)

    def __init__(self):
        self.ctr = 0
        self.starting_index_not_to_be_shuffled = 0
        self.adder()
        start_time = time.time()
        print('started')
        self.df = pd.read_csv('resources.csv', engine='c')
        print("without shuffling dataset contains " + str(len(self.df)) + " rows and " + str(
            len(self.df.columns)) + " columns")
        self.df.iloc[:self.starting_index_not_to_be_shuffled, :] = self.df.iloc[:self.starting_index_not_to_be_shuffled,
                                                                   :].sample(frac=1).reset_index(
            drop=True)  # shuffling dataframe
        print("after shuffling dataset contains " + str(len(self.df)) + " rows and " + str(
            len(self.df.columns)) + " columns")
        self.df.to_csv('newresources.csv')  # shuffled dataset
        print(self.df)

        file = open("input dimension for model.txt", "w")
        file.write(str(len(self.df.columns) - 1))
        file.close()

        print("\nwhole process takes %s seconds" % (time.time() - start_time))

# Jalankan
scream()