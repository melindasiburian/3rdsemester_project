# this file is made for sound_classifier_nueral.py
# positive sound mean the sound that we want to predict
# negative sound mean sound except positive sound
import time
import psutil
import numpy as np
import pandas as pd
import os,threading
from sklearn.preprocessing import StandardScaler
from scipy.io.wavfile import read
import os
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split


class scream():
    def adder(self):
        all_files = []
        max_len = 0

        # Kumpulkan file dari folder negative dan positive
        for label, folder in [(0, 'negative'), (1, 'positive')]:
            for fname in os.listdir(folder):
                filepath = os.path.join(folder, fname)
                try:
                    _, rs = read(filepath)
                    rs = rs.astype(np.int16)
                    max_len = max(max_len, len(rs))
                    rs = np.insert(rs, 0, label)  # prepend label
                    all_files.append(pd.Series(rs))
                except Exception as e:
                    print(f"removed {filepath}, error: {e}")
                    os.remove(filepath)
                    continue

        # Padding
        arr_padded = [s.reindex(range(max_len + 1), fill_value=0) for s in all_files]
        df = pd.DataFrame(arr_padded).dropna(axis=1)

        # Split 80-20
        df_train, df_test = train_test_split(df, test_size=0.2, random_state=42, shuffle=True)

        # Gabungkan kembali (training di atas, testing di bawah)
        df_combined = pd.concat([df_train, df_test], ignore_index=True)

        # Simpan index awal testing
        testing_start_index = len(df_train)
        with open("begining index of testing files.txt", "w") as file:
            file.write(str(testing_start_index))

        # Simpan CSV
        df_combined.to_csv('resources.csv', index=False)

        print(f"{len(df_train)} training files and {len(df_test)} testing files have been added.")
        self.starting_index_not_to_be_shuffled = testing_start_index

    def __init__(self):
        self.ctr = 0
        self.adder()
        start_time = time.time()
        print('started')
        self.df = pd.read_csv('resources.csv', engine='c')
        print("dataset contains " + str(len(self.df)) + " rows and " + str(len(self.df.columns)) + " columns")

        # Optional: tidak perlu shuffle karena data sudah diacak via train_test_split
        self.df.to_csv('newresources.csv', index=False)

        with open("input dimension for model.txt", "w") as file:
            file.write(str(len(self.df.columns) - 1))

        print("\nwhole process takes %s seconds" % (time.time() - start_time))
        print(self.df)

# Jalankan
scream()