from sklearn import svm
import numpy as np
from sklearn import mixture
from numpy import genfromtxt
import pandas as pd
from sklearn.metrics import accuracy_score

def tetsting_unit( ):
    tester = []
    import librosa
    filename = "C:\\Users\\Melinda Siburian\\PycharmProjects\\3rd semester project\\machine learning\\audio_dataset\\145611-6-2-0.wav"
    y, sr = librosa.load(filename)
    mfccs = np.mean(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40).T, axis=0)
    tester.append(mfccs)
    tester = np.array(tester)
    return tester


x_train = genfromtxt('modified_data.csv', delimiter=',')
y_train = genfromtxt('solution.csv',delimiter=',')
#print(x_train.shape, y_train.shape)
clf = svm.SVC(kernel="linear")
clf.fit(x_train, y_train)
prd=clf.predict(tetsting_unit())
if prd[0] == 2:
    print("phase 1 clear")
    import phase2_speech_vs_high_pitch as sf
    ok = sf.second_para.predict(tetsting_unit())
    if ok[0] == 1:
        print('scream')
    else:
        print('speech')
else:
    print("noise")