import numpy as np
from numpy import genfromtxt
from sklearn import svm
from sklearn.metrics import classification_report, accuracy_score
from sklearn.model_selection import train_test_split
import librosa

def tetsting_unit():
    tester = []
    filename = "C:\\Users\\Melinda Siburian\\PycharmProjects\\3rd semester project\\machine learning\\audio_dataset\\190894-2-0-7.wav"
    y, sr = librosa.load(filename)
    mfccs = np.mean(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40).T, axis=0)
    tester.append(mfccs)
    tester = np.array(tester)
    return tester

# Load data
x = genfromtxt('modified_data.csv', delimiter=',')
y = genfromtxt('solution.csv', delimiter=',')

# Split untuk evaluasi
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# Train model
clf = svm.SVC(kernel="linear")
clf.fit(X_train, y_train)

# Evaluasi model
y_pred = clf.predict(X_test)
print("Akurasi:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# Prediksi dari satu file input
prd = clf.predict(tetsting_unit())

if prd[0] == 2:
    print("phase 1 clear")
    import phase2_speech_vs_high_pitch as sf
    ok = sf.second_para.predict(tetsting_unit())
    if ok[0] == 1:
        print('scream')
    else:
        print('speech')
else:
    print("noise")


