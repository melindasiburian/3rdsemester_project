from numpy import genfromtxt
from sklearn import svm
from sklearn.metrics import classification_report, accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
import numpy as np

#Load data
x_train = genfromtxt('speech.csv', delimiter=',')
y_train = genfromtxt('id_of_it.csv', delimiter=',')

# Normalisasi fitur agar setiap kolom memiliki skala yang sebanding
scaler = StandardScaler()
x_train_scaled = scaler.fit_transform(x_train)

# Cek distribusi label
unique, counts = np.unique(y_train, return_counts=True)
print("Distribusi Label:", dict(zip(unique, counts)))

# Cross-validation untuk evaluasi lebih stabil
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Buat model SVM dengan regularisasi
model = svm.SVC(kernel="linear", C=1.0)  # Anda bisa coba C=0.1, 1, 10 untuk tuning

# Evaluasi dengan cross-validation
scores = cross_val_score(model, x_train_scaled, y_train, cv=cv)
print(f"Akurasi rata-rata Cross-Validation: {scores.mean():.4f}")
print("Akurasi per fold:", scores)

# Train model pada seluruh data setelah validasi
model.fit(x_train_scaled, y_train)

# Simulasi testing untuk mendapatkan classification report
X_train_, X_test_, y_train_, y_test_ = train_test_split(
    x_train_scaled, y_train, test_size=0.2, random_state=42, stratify=y_train
)
model.fit(X_train_, y_train_)
y_pred = model.predict(X_test_)

# Hasil akhir
print("Akurasi pada test split:", accuracy_score(y_test_, y_pred))
print("Classification Report:\n", classification_report(y_test_, y_pred))